// Seleccionamos la tarjeta por su ID
const card = document.getElementById('warframeCard');

// Momento en el que el mouse entra a la caja
card.addEventListener('mouseenter', () => {
    console.log("Desplegando el lore de Chroma...");
});

// Momento en el que el mouse sale de la caja
card.addEventListener('mouseleave', () => {
    console.log("Cerrando archivo de Warframe.");
});